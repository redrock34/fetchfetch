import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    private var myArray: [String] = ["First","second"]
    
    
    
    
    
     var myTableView =  UITableView()

    override func viewDidLoad() {
        super.viewDidLoad()

        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "MyCell")
        myTableView.dataSource = self
        myTableView.delegate = self
        
        
        
        self.view.addSubview(myTableView)
        myTableView.translatesAutoresizingMaskIntoConstraints = false
       
myTableView.register(MyCell.self, forCellReuseIdentifier: "MyCell")
   

               
               NSLayoutConstraint.activate([

                   myTableView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.90),
                   myTableView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
                   myTableView.topAnchor.constraint(equalTo: view.topAnchor),
                   myTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),



               ])
        
    }
    
   

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Num: \(indexPath.row)")
        print("Value: \(myArray[indexPath.row])")
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MyCell
        cell.label.text = ""
        
        
      
        cell.button.tag = myArray[indexPath.row]


        cell.buttonTapCallback = { [weak self] in
               guard let self = self else { return }

               self.myArray.append("NewItem")

               self.myTableView.reloadData()
           }
        
  cell.didDelete = { [weak self] tag in
    self?.myArray.remove(at:tag)
    self?.myTableView.reloadData()
           return cell
  }
        
        
        
        

        

    
    }

    
    
}
class MyCell: UITableViewCell {
    
    var buttonTapCallback: () -> ()  = { }

//    var didDelete: (Int) -> ()  = { }
    
    let button: UIButton = {
        let btn = UIButton()
        btn.setTitle("Button", for: .normal)
        btn.backgroundColor = .systemPink
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        return btn
    }()
    let deleteButton: UIButton = {
         let btn = UIButton()
         btn.setTitle("Delete", for: .normal)
        btn.backgroundColor = .green
         btn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
         return btn
     }()
    
    let label: UILabel = {
       let lbl = UILabel()
        lbl.font = UIFont.systemFont(ofSize: 16)
        lbl.textColor = .systemPink
       return lbl
    }()
    
    @objc func didTapButton() {
        buttonTapCallback()
    }
    
//    @objc func didTapDelete() {
//     didDelete(button.tag)
//    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        //Add button
        contentView.addSubview(button)
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
//        deleteButton.addTarget(self, action: #selector(  didDelete(button.tag)), for: .touchUpInside)
        //Set constraints as per your requirements
        button.translatesAutoresizingMaskIntoConstraints = false
        button.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20).isActive = true
        button.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10).isActive = true
        button.widthAnchor.constraint(equalToConstant: 100).isActive = true
        button.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10).isActive = true
        
        //Add label
        contentView.addSubview(label)
        //Set constraints as per your requirements
        label.translatesAutoresizingMaskIntoConstraints = false
        label.leadingAnchor.constraint(equalTo: button.trailingAnchor, constant: 20).isActive = true
        label.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10).isActive = true

        label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10).isActive = true
        
        
        
        
        
        
        
        
        
        
        
        contentView.addSubview(deleteButton)
        //Set constraints as per your requirements
        deleteButton.translatesAutoresizingMaskIntoConstraints = false
        deleteButton.leadingAnchor.constraint(equalTo: label.trailingAnchor, constant: 20).isActive = true
        deleteButton.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10).isActive = true

        deleteButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10).isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

